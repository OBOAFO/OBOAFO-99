# Reckoner — Scientific Calculator (PWA)

A self-contained scientific calculator (`index.html`) plus the two files that
make it installable as an app: `manifest.json` and `service-worker.js`, with
generated icons in `icons/`.

## Try it right now
Open `index.html` in a browser — it works immediately, no build step, no
dependencies. Everything (HTML/CSS/JS) is in that one file.

## Make it installable ("Add to Home Screen" / desktop install)
Browsers only offer the install prompt over **HTTPS** (or `localhost`) — not
over `file://`. So to get the actual "installable app" behavior, put these
four files/folders on any static host, keeping the same folder structure:

```
index.html
manifest.json
service-worker.js
icons/
  icon-192.png
  icon-512.png
```

Easiest free options:
- **GitHub Pages** — push this folder to a repo, enable Pages, done.
- **Netlify / Vercel** — drag-and-drop the folder onto their web dashboard.
- **Cloudflare Pages** — same idea, drag-and-drop deploy.

Once it's live over HTTPS:
- **Android / Chrome desktop**: visit the site → menu → "Install app" (or
  the install icon in the address bar).
- **iOS Safari**: Share button → "Add to Home Screen".
- It'll then launch full-screen with its own icon, and works offline thanks
  to the service worker caching.

## Features
- Basic + scientific ops: `sin cos tan asin acos atan ln log √ x² xʸ n! 1/x π`
- Degree/Radian toggle switch
- Memory: `MC MR M+ M−`
- Calculation history (click any past result to reuse it)
- Full keyboard support (numbers, `+ - * / ^ ( ) % ! Enter Backspace Esc`)
- Own expression parser (tokenizer → shunting-yard → RPN evaluator) — no
  `eval()` used anywhere

## Customizing
- Colors/fonts: CSS custom properties at the top of `index.html`'s `<style>`
  block (`--lcd-bg`, `--accent-amber`, etc.)
- Icons: regenerate `icons/icon-192.png` and `icons/icon-512.png` with your
  own artwork at those exact sizes; the manifest already points to them.
- App name: edit `name`/`short_name` in `manifest.json`.
